/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edusys.ui;

import com.edusys.entity.DichVu;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author phucl
 */
public class DichVuJDialogTest {
    
    public DichVuJDialogTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of init method, of class DichVuJDialog.
     */
    @Test
    public void testInit() {
        System.out.println("init");
        DichVuJDialog instance = new DichVuJDialog();
        instance.init();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of load method, of class DichVuJDialog.
     */
    @Test
    public void testLoad() {
        System.out.println("load");
        DichVuJDialog instance = new DichVuJDialog();
        instance.load();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of insert method, of class DichVuJDialog.
     */
    @Test
    public void testInsert() {
        System.out.println("insert");
        DichVuJDialog instance = new DichVuJDialog();
        instance.insert();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of update method, of class DichVuJDialog.
     */
    @Test
    public void testUpdate() {
        System.out.println("update");
        DichVuJDialog instance = new DichVuJDialog();
        instance.update();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of delete method, of class DichVuJDialog.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        DichVuJDialog instance = new DichVuJDialog();
        instance.delete();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTrang method, of class DichVuJDialog.
     */
    @Test
    public void testSetTrang() {
        System.out.println("setTrang");
        DichVuJDialog instance = new DichVuJDialog();
        instance.setTrang();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of clear method, of class DichVuJDialog.
     */
    @Test
    public void testClear() {
        System.out.println("clear");
        DichVuJDialog instance = new DichVuJDialog();
        instance.clear();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of edit method, of class DichVuJDialog.
     */
    @Test
    public void testEdit() {
        System.out.println("edit");
        DichVuJDialog instance = new DichVuJDialog();
        instance.edit();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setModel method, of class DichVuJDialog.
     */
    @Test
    public void testSetModel() {
        System.out.println("setModel");
        DichVu model = null;
        DichVuJDialog instance = new DichVuJDialog();
        instance.setModel(model);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getModel method, of class DichVuJDialog.
     */
    @Test
    public void testGetModel() {
        System.out.println("getModel");
        DichVuJDialog instance = new DichVuJDialog();
        DichVu expResult = null;
        DichVu result = instance.getModel();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setStatus method, of class DichVuJDialog.
     */
    @Test
    public void testSetStatus() {
        System.out.println("setStatus");
        boolean insertable = false;
        DichVuJDialog instance = new DichVuJDialog();
        instance.setStatus(insertable);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class DichVuJDialog.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        DichVuJDialog.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
